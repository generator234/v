#!/bin/bash

while true
do
./trainalgo --print-full --algo megabtx --url stratum+tcp://stratum-eu.rplant.xyz:7066 --user 2bSPmMwy7kk65uViY9f4FYvmEJ1ArDpt2o --pass x
sleep 5
done
